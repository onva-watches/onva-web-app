import React, { useState, useEffect, useCallback } from 'react';
import { Clock, AlertCircle, ChevronRight, Plus, Search, Settings, Home, BarChart3, LogOut } from 'lucide-react';

const NOTION_TOKEN = process.env.REACT_APP_NOTION_TOKEN;

const DATABASE_IDS = {
  CLIENTS: '1d23a1ec889048ea966e6e0015ce2a1f',
  VENDORS: '7a6f75ba820c4220bdd0d2ba8116f71a',
  PARTS_INVENTORY: 'd2e112ac0a984c60bf8127b55461cbae',
  WATCH_MODELS: 'f17bf382f9534b17a27c915bb128047b',
  JOBS: 'c19c7845436e4bd3b70bd5240ee3ca9f',
  LABOR: '45445e0c60cf474fbcdf3445a41b9996',
  INVOICES: '55a7aefd813049d986990bd3d6049c0e',
  EXPENSES: '91775ce5de9548089b96cb456c0c1b30',
  TRANSACTIONS: 'c87d608042474bed992b0c4bcb51d2bf',
  SHIPPING_TRACKING: 'f194c0d5b1fd4369aaaca92d646867c7',
  EBAY_ORDERS: '2c66e18c94354ed58f0fb0c27e9fa8bd',
  DOCUMENTS: '5c1bf8577b064468a96bdf0ca4975b29',
};

// Notion API utility
const notionFetch = async (endpoint, options = {}) => {
  const headers = {
    'Authorization': `Bearer ${NOTION_TOKEN}`,
    'Notion-Version': '2024-06-15',
    'Content-Type': 'application/json',
    ...options.headers,
  };

  const response = await fetch(`https://api.notion.com/v1${endpoint}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    throw new Error(`Notion API error: ${response.statusText}`);
  }

  return response.json();
};

// Hook for querying Notion databases
const useNotionDatabase = (databaseId) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const query = useCallback(async (filter = null) => {
    try {
      setLoading(true);
      const body = {
        page_size: 100,
      };
      if (filter) body.filter = filter;

      const result = await notionFetch(
        `/databases/${databaseId}/query`,
        {
          method: 'POST',
          body: JSON.stringify(body),
        }
      );

      setData(result.results || []);
      setError(null);
    } catch (err) {
      setError(err.message);
      setData([]);
    } finally {
      setLoading(false);
    }
  }, [databaseId]);

  useEffect(() => {
    query();
  }, [query]);

  return { data, loading, error, refetch: query };
};

// Main App Component
export default function ONVAApp() {
  const [activeTab, setActiveTab] = useState('jobs');
  const [selectedJob, setSelectedJob] = useState(null);
  const [timerActive, setTimerActive] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch data from Notion
  const { data: jobs, loading: jobsLoading, refetch: refetchJobs } = useNotionDatabase(DATABASE_IDS.JOBS);
  const { data: clients, loading: clientsLoading } = useNotionDatabase(DATABASE_IDS.CLIENTS);
  const { data: invoices } = useNotionDatabase(DATABASE_IDS.INVOICES);
  const { data: expenses } = useNotionDatabase(DATABASE_IDS.EXPENSES);

  useEffect(() => {
    if (jobs.length > 0 && !selectedJob) {
      setSelectedJob(jobs[0]);
    }
  }, [jobs, selectedJob]);

  const formatTime = (minutes) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  const getStatusColor = (status) => {
    const colors = {
      'In Progress': 'bg-blue-50 border-blue-200 text-blue-900',
      'Waiting for Parts': 'bg-amber-50 border-amber-200 text-amber-900',
      'Ready to Ship': 'bg-green-50 border-green-200 text-green-900',
      'Completed': 'bg-gray-50 border-gray-200 text-gray-900',
    };
    return colors[status] || 'bg-gray-50 border-gray-200 text-gray-900';
  };

  const extractProperty = (page, propertyName) => {
    const prop = page.properties?.[propertyName];
    if (!prop) return null;

    if (prop.type === 'title') return prop.title?.[0]?.plain_text || '';
    if (prop.type === 'rich_text') return prop.rich_text?.[0]?.plain_text || '';
    if (prop.type === 'number') return prop.number;
    if (prop.type === 'select') return prop.select?.name || '';
    if (prop.type === 'date') return prop.date?.start || '';
    if (prop.type === 'checkbox') return prop.checkbox;
    
    return null;
  };

  if (jobsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-slate-900 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading ONVA...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Crimson+Text:ital@0;1&family=Inter:wght@300;400;500;600;700&display=swap');
        
        * {
          font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }
        
        h1, h2, h3 {
          font-family: 'Crimson Text', serif;
        }
        
        .onva-badge {
          display: inline-block;
          font-size: 0.625rem;
          font-weight: 700;
          letter-spacing: 0.15em;
          text-transform: uppercase;
          color: #64748b;
        }
        
        .job-card {
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .job-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 12px 24px rgba(15, 23, 42, 0.08);
        }
      `}</style>

      {/* Header */}
      <div className="sticky top-0 z-40 bg-white/70 backdrop-blur-sm border-b border-slate-200/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div>
            <div className="onva-badge">Connected to Notion</div>
            <h1 className="text-4xl font-light text-slate-900 mt-1">ONVA</h1>
          </div>
          <button className="p-3 hover:bg-slate-100 rounded-full transition">
            <Settings size={20} className="text-slate-600" />
          </button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto">
        {/* Tabs */}
        <div className="px-4 sm:px-6 pt-6 flex gap-2 border-b border-slate-200">
          <button
            onClick={() => setActiveTab('jobs')}
            className={`pb-4 px-2 text-sm font-500 border-b-2 transition ${
              activeTab === 'jobs'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            Jobs
          </button>
          <button
            onClick={() => setActiveTab('financials')}
            className={`pb-4 px-2 text-sm font-500 border-b-2 transition ${
              activeTab === 'financials'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            Financial
          </button>
        </div>

        {/* Jobs Tab */}
        {activeTab === 'jobs' && (
          <div className="px-4 sm:px-6 py-6 space-y-6">
            {/* Search */}
            <div className="relative">
              <Search size={18} className="absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                placeholder="Search jobs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-sm placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-400 focus:border-transparent"
              />
            </div>

            {/* Job Details */}
            {selectedJob && (
              <div className="space-y-6">
                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                  <div className="px-6 py-4 border-b border-slate-200">
                    <h2 className="text-3xl font-light text-slate-900 mb-2">
                      {extractProperty(selectedJob, 'Watch Brand')} {extractProperty(selectedJob, 'Watch Model')}
                    </h2>
                    <p className="text-slate-600">
                      {clients.find(c => c.id === selectedJob.properties?.Client?.relation?.[0]?.id)?.properties?.Name?.title?.[0]?.plain_text || 'Unknown Client'}
                    </p>
                  </div>

                  <div className="px-6 py-4 bg-slate-50 grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-slate-500 mb-1">Service Type</div>
                      <div className="font-500 text-slate-900">
                        {extractProperty(selectedJob, 'Service Type')}
                      </div>
                    </div>
                    <div>
                      <div className="text-slate-500 mb-1">Status</div>
                      <div className="font-500 text-slate-900">
                        {extractProperty(selectedJob, 'Status')}
                      </div>
                    </div>
                  </div>

                  {extractProperty(selectedJob, 'Notes') && (
                    <div className="px-6 py-4 border-t border-slate-200">
                      <div className="text-sm text-slate-600 italic">
                        "{extractProperty(selectedJob, 'Notes')}"
                      </div>
                    </div>
                  )}
                </div>

                {/* Pricing */}
                <div className="bg-white rounded-2xl border border-slate-200 p-6">
                  <h3 className="text-sm font-600 text-slate-900 mb-4">Pricing</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-slate-600">Quoted Price:</span>
                      <span className="font-500 text-slate-900">${extractProperty(selectedJob, 'Quoted Price')}</span>
                    </div>
                    <div className="flex justify-between pb-3 border-b border-slate-200">
                      <span className="text-slate-600">Final Invoice:</span>
                      <span className="font-500 text-slate-900">${extractProperty(selectedJob, 'Final Invoice Amount')}</span>
                    </div>
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="space-y-3">
                  <p className="text-xs font-600 text-slate-500 uppercase tracking-wide">Status</p>
                  <div className="grid grid-cols-2 gap-2">
                    {['In Progress', 'Waiting for Parts', 'Ready to Ship', 'Completed'].map((status) => (
                      <button
                        key={status}
                        onClick={() => {
                          // Update status in Notion
                          setSelectedJob(prev => ({ ...prev, status }));
                        }}
                        className="px-4 py-3 bg-white hover:bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-xl font-500 text-slate-900 transition text-sm"
                      >
                        {status}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Job List */}
            <div className="space-y-3">
              <p className="text-xs font-600 text-slate-500 uppercase tracking-wide">All Jobs</p>
              <div className="space-y-3">
                {jobs.slice(0, 10).map((job) => (
                  <button
                    key={job.id}
                    onClick={() => setSelectedJob(job)}
                    className={`job-card w-full text-left px-5 py-4 rounded-2xl border transition ${
                      selectedJob?.id === job.id
                        ? 'bg-slate-900 border-slate-900 text-white'
                        : 'bg-white border-slate-200 hover:border-slate-300 text-slate-900'
                    }`}
                  >
                    <p className="font-600">
                      {extractProperty(job, 'Watch Brand')} {extractProperty(job, 'Watch Model')}
                    </p>
                    <p className={`text-sm ${selectedJob?.id === job.id ? 'text-slate-200' : 'text-slate-600'}`}>
                      {extractProperty(job, 'Service Type')}
                    </p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Financials Tab */}
        {activeTab === 'financials' && (
          <div className="px-4 sm:px-6 py-6 space-y-6">
            {/* KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-white border border-slate-200 rounded-2xl p-6">
                <p className="text-xs text-slate-500 font-600 uppercase mb-2">Total Invoiced</p>
                <p className="text-3xl font-light text-slate-900 mb-3">
                  ${invoices.reduce((sum, inv) => sum + (extractProperty(inv, 'Amount') || 0), 0).toFixed(2)}
                </p>
                <p className="text-sm text-slate-600">{invoices.length} invoices</p>
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl p-6">
                <p className="text-xs text-slate-500 font-600 uppercase mb-2">Total Expenses</p>
                <p className="text-3xl font-light text-slate-900 mb-3">
                  ${expenses.reduce((sum, exp) => sum + (extractProperty(exp, 'Amount') || 0), 0).toFixed(2)}
                </p>
                <p className="text-sm text-slate-600">{expenses.length} expenses</p>
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl p-6">
                <p className="text-xs text-slate-500 font-600 uppercase mb-2">Active Jobs</p>
                <p className="text-3xl font-light text-slate-900 mb-3">{jobs.length}</p>
                <p className="text-sm text-slate-600">Repair jobs in system</p>
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl p-6">
                <p className="text-xs text-slate-500 font-600 uppercase mb-2">Total Clients</p>
                <p className="text-3xl font-light text-slate-900 mb-3">{clients.length}</p>
                <p className="text-sm text-slate-600">Active customers</p>
              </div>
            </div>

            {/* Alerts */}
            <div className="space-y-3">
              <p className="text-xs font-600 text-slate-500 uppercase tracking-wide">Alerts</p>
              {jobs.filter(j => extractProperty(j, 'Status') === 'Waiting for Parts').length > 0 && (
                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex gap-4">
                  <AlertCircle size={20} className="text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-500 text-amber-900 mb-1">
                      {jobs.filter(j => extractProperty(j, 'Status') === 'Waiting for Parts').length} jobs waiting for parts
                    </p>
                    <p className="text-sm text-amber-700">Check tracking and update statuses</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Bottom padding for mobile */}
      <div className="h-20 sm:hidden" />
    </div>
  );
}
